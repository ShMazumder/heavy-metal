==============================================================================
Heavy Metal Geospatial Database — Bangladesh Rivers (2010–2024)
==============================================================================

CONTENTS:
  heavy_metal.db                  Master SQLite relational database (4 tables)
  water_data.csv                  Surface water assays (268 rows × 49 cols)
  sediment_data.csv               Bed sediment assays (289 rows × 32 cols)
  stations.csv                    Observation stations (426 rows × 14 cols)
  studies.csv                     Study metadata & instrumentation (28 rows)
  master_harmonized.csv           Denormalized master table (557 rows × 59 cols)
  station_hydrorivers_matched.csv Topological reach join table (213 unique stations)
  hydrorivers_bangladesh.gpkg     HydroSHEDS HydroRIVERS clipped network
  bangladesh_boundary.geojson     National boundary polygon (WGS84)

COORDINATE SYSTEM: EPSG:4326 (WGS84)
LICENSE: CC-BY 4.0
CODE: https://github.com/ShMazumder/heavy-metal
